using UnityEngine;

public class CollisionHandler : MonoBehaviour
{
    public PlayerMovement playerMovement;
    public AudioClip collisionSound;

    private GAMEMANAGER gm;
    private bool collisionHandled = false;

    void Awake()
    {
        if (playerMovement == null)
        {
            playerMovement =
                GetComponent<PlayerMovement>();

            if (playerMovement == null)
            {
                playerMovement =
                    GetComponentInParent<
                        PlayerMovement
                    >();
            }
        }

        gm =
            FindFirstObjectByType<
                GAMEMANAGER
            >();
    }

    void OnCollisionEnter(
        Collision collision
    )
    {
        if (playerMovement == null)
            return;

        // =====================================================
        // OBSTACLE
        // =====================================================

        if (
            collision.collider.CompareTag("OBSTACLE") ||
            collision.collider.CompareTag("Obstacle")
        )
        {
            // =================================================
            // STRIKE
            // =================================================

            if (playerMovement.isStriking)
            {
                Debug.Log(
                    "STRIKE HIT: " +
                    collision.gameObject.name
                );

                if (
                    SFXManager.instance != null &&
                    collisionSound != null
                )
                {
                    SFXManager.instance.PlaySound(
                        collisionSound
                    );
                }

                playerMovement
                    .MaintainStrikeMomentum();

                if (Analytics.Instance != null)
                {
                    Analytics.Instance.ObstacleDestroyed(
                        Analytics.Instance.GetCurrentLevel(),
                        collision.gameObject.name
                    );
                }

                Destroy(
                    collision.gameObject
                );

                return;
            }

            // =================================================
            // INEVITABLE
            // =================================================

            if (playerMovement.isInevitable)
            {
                Debug.Log(
                    "INEVITABLE - OBSTACLE IGNORED"
                );

                if (
                    collision.collider != null
                )
                {
                    Collider playerCollider =
                        GetComponent<Collider>();

                    if (
                        playerCollider != null
                    )
                    {
                        Physics.IgnoreCollision(
                            playerCollider,
                            collision.collider
                        );
                    }
                }

                return;
            }

            // =================================================
            // NORMAL COLLISION
            // =================================================

            if (collisionHandled)
                return;

            collisionHandled = true;

            Debug.Log(
                "PLAYER HIT OBSTACLE"
            );

            if (gm != null)
            {
                gm.EndGame();
            }

            return;
        }

        // =====================================================
        // GROUND
        // =====================================================

        if (
            collision.collider.CompareTag("GROUND") ||
            collision.collider.CompareTag("Ground")
        )
        {
            Debug.Log(
                "PLAYER ON GROUND"
            );
        }
    }
}