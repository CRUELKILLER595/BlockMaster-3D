using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Button))]
public class PauseButton : MonoBehaviour
{
    public GameObject pauseMenu;

    private Button pauseButton;
    private MusicManager musicManager;

    private bool isPaused = false;

    void Awake()
    {
        pauseButton =
            GetComponent<Button>();

        musicManager =
            FindFirstObjectByType<
                MusicManager
            >();
    }

    void Start()
    {
        if (pauseButton == null)
        {
            Debug.LogError(
                "PauseButton: Button missing."
            );

            return;
        }

        if (pauseMenu == null)
        {
            Debug.LogError(
                "PauseButton: Pause Menu missing."
            );

            return;
        }

        pauseButton.onClick.AddListener(
            TogglePause
        );

        pauseMenu.SetActive(false);
    }

    void Update()
    {
        Keyboard keyboard =
            Keyboard.current;

        if (
            keyboard != null &&
            keyboard.escapeKey.wasPressedThisFrame
        )
        {
            TogglePause();
        }
    }

    void TogglePause()
    {
        if (isPaused)
        {
            ResumeLevel();
        }
        else
        {
            PauseLevel();

            isPaused = true;

            if (pauseMenu != null)
            {
                pauseMenu.SetActive(true);
            }
        }
    }

    public void PauseLevel()
    {
        Time.timeScale = 0f;

        if (musicManager != null)
        {
            musicManager.PauseMusic();
        }
    }

    public void ResumeLevel()
    {
        isPaused = false;

        Time.timeScale = 1f;

        if (pauseMenu != null)
        {
            pauseMenu.SetActive(false);
        }

        if (musicManager != null)
        {
            musicManager.ResumeMusic();
        }
    }

    public void RestartLevel()
    {
        Time.timeScale = 1f;

        GAMEMANAGER gm =
            FindFirstObjectByType<
                GAMEMANAGER
            >();

        if (gm != null)
        {
            gm.Restart();
        }
    }
}