using UnityEngine;
using TMPro;

public class TotalScore : MonoBehaviour
{
    public TextMeshProUGUI totalScoreText;

    public SCORE SCORE;
    public TIMER timer;

    void OnEnable()
    {
        UpdateTotalScore();
    }

    public void UpdateTotalScore()
    {
        if (totalScoreText == null)
        {
            Debug.LogError(
                "Total Score Text not assigned!"
            );

            return;
        }

        if (ScoreManager.instance == null)
        {
            Debug.LogError(
                "ScoreManager missing!"
            );

            return;
        }

        if (SCORE == null)
        {
            Debug.LogError(
                "SCORE missing!"
            );

            return;
        }

        int leftTime = 0;

        if (timer != null)
        {
            leftTime =
                Mathf.CeilToInt(
                    timer.LevelTime
                );
        }

        int totalScore =
            ScoreManager.instance.coins * 5 +
            Mathf.FloorToInt(
                SCORE.DistanceScore * 0.5f
            ) +
            leftTime * 2;

        totalScoreText.text =
            "Total Score: " +
            totalScore;
    }
}