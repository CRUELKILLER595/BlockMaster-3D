using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PuzzleZone : MonoBehaviour
{
    public float abilityTime;

    private float timer;
    private bool active;

    public GameObject puzzleUI;
    public TMP_Text timertext;

    private PlayerMovement player;

    void Start()
    {
        puzzleUI.SetActive(false);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !active)
        {
            player = other.GetComponent<PlayerMovement>();

            player.canMoveBackward = true;
            timer = abilityTime;
            active = true;

            puzzleUI.SetActive(true);
        }
    }

    void Update()
    {
        if (!active) return;

        timer -=Time.deltaTime*0.8f;
        timertext.text=Mathf.CeilToInt(timer).ToString();


        if (timer <= 0)
        {
            DisableAbility();
        }
    }

    void DisableAbility()
    {
        active = false;

        if (player != null)
            player.canMoveBackward = false;

        puzzleUI.SetActive(false);
        timertext.enabled = false;
    }
}

