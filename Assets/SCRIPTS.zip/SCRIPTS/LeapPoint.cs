using UnityEngine;

public class LeapPoint : MonoBehaviour
{
    public float verticalForce = 100f;
    public float horizontalForce = 20f;
    public float cooldownTime = 1f; 
    public AudioClip leapSound;
    public AudioClip pauseSound;
    // Time in seconds before the leap point can be used again
    public Vector3 launchDirection = Vector3.forward; 
    // direction of horizontal push

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Rigidbody rb = other.GetComponent<Rigidbody>();

            if (rb != null)
            {
                // Reset velocity (important for consistent jump)

                // Calculate force
                Vector3 force = launchDirection.normalized * horizontalForce 
                                + Vector3.up * verticalForce;

                // Apply force instantly
                rb.AddForce(force, ForceMode.Impulse);
                AudioSource.PlayClipAtPoint(leapSound, transform.position);
                
            
            }
        }
    }
}