using UnityEngine;

public class RumbleZone : MonoBehaviour
{
    public RumbleBlock[] rumbleBlocks;
    public GameObject rumbleUI;
    private bool active = false;

    void Start()
    {
        if (rumbleUI != null)
            rumbleUI.SetActive(false);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !active)
        {
            active = true;

            Debug.Log("RUMBLE ZONE ENTERED");

            if (rumbleUI != null)
                rumbleUI.SetActive(true);

            foreach (RumbleBlock block in rumbleBlocks)
            {
                block.StartRumble();
            }
        }
    }
}

