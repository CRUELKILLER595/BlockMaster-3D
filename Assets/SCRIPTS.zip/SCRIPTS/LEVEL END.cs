using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelEnd : MonoBehaviour
{
    public SCORE SCORE;
    public TIMER timer;

    private bool levelCompleted = false;

    void OnTriggerEnter(
        Collider other
    )
    {
        if (levelCompleted)
            return;

        if (!other.CompareTag("Player"))
            return;

        levelCompleted = true;

        Debug.Log(
            "PLAYER HIT LEVEL END"
        );

        // =====================================================
        // GET LEVEL
        // =====================================================

        int levelIndex =
            SceneManager.GetActiveScene()
                .buildIndex - 1;

        // =====================================================
        // TIMER
        // =====================================================

        int leftTime = 0;

        if (timer != null)
        {
            timer.StopTimer();

            leftTime =
                Mathf.CeilToInt(
                    timer.LevelTime
                );
        }

        // =====================================================
        // DISTANCE
        // =====================================================

        float distance = 0f;

        if (SCORE != null)
        {
            distance =
                SCORE.DistanceScore;
        }
        else if (SCORE.instance != null)
        {
            distance =
                SCORE.instance.DistanceScore;
        }

        // =====================================================
        // COINS
        // =====================================================

        int coins = 0;

        if (ScoreManager.instance != null)
        {
            coins =
                ScoreManager.instance.coins;
        }

        // =====================================================
        // SCORE
        // =====================================================

        int totalScore =
            coins * 5 +
            Mathf.FloorToInt(
                distance * 0.5f
            ) +
            leftTime * 2;

        Debug.Log(
            "FINAL SCORE: " +
            totalScore
        );

        // =====================================================
        // HIGH SCORE
        // =====================================================

        int currentHighScore =
            PlayerPrefs.GetInt(
                "HighScore_" + levelIndex,
                0
            );

        if (
            totalScore >
            currentHighScore
        )
        {
            PlayerPrefs.SetInt(
                "HighScore_" + levelIndex,
                totalScore
            );

            PlayerPrefs.Save();

            Debug.Log(
                "NEW HIGH SCORE: " +
                totalScore
            );
        }

        // =====================================================
        // ANALYTICS
        // =====================================================

        if (Analytics.Instance != null)
        {
            Analytics.Instance.LevelCompleted(
                levelIndex,
                distance,
                coins,
                totalScore
            );
        }

        // =====================================================
        // GAME MANAGER
        // =====================================================

        GAMEMANAGER gm =
            FindFirstObjectByType<
                GAMEMANAGER
            >();

        if (gm != null)
        {
            gm.OnLevelComplete(
                levelIndex
            );
        }
    }
}