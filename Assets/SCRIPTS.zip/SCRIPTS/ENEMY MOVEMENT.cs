using UnityEngine;

public class ENEMYMOVEMENT : MonoBehaviour
{
    public PlayerMovement playerMovement;
    public GAMEMANAGER gm;

    private CollisionHandler co;

    private Collider[] enemyColliders;
    private Collider[] playerColliders;

    // =========================================================
    // AWAKE
    // =========================================================

    void Awake()
    {
        co =
            FindFirstObjectByType<CollisionHandler>();

        if (playerMovement == null)
        {
            playerMovement =
                FindFirstObjectByType<PlayerMovement>();
        }

        if (gm == null)
        {
            gm =
                FindFirstObjectByType<GAMEMANAGER>();
        }

        enemyColliders =
            GetComponentsInChildren<Collider>();

        if (playerMovement != null)
        {
            playerColliders =
                playerMovement
                    .GetComponentsInChildren<Collider>();
        }
    }

    // =========================================================
    // ENABLE
    // =========================================================

    void OnEnable()
    {
        if (playerMovement == null)
        {
            playerMovement =
                FindFirstObjectByType<PlayerMovement>();
        }

        if (
            playerMovement != null &&
            playerMovement.isInevitable
        )
        {
            SetPlayerCollisionIgnored(
                true
            );
        }
    }

    // =========================================================
    // COLLISION
    // =========================================================

    void OnCollisionEnter(
        Collision collision
    )
    {
        if (!collision.collider.CompareTag("Player"))
            return;

        if (playerMovement == null)
            return;

        // =====================================================
        // INEVITABLE
        // =====================================================

        if (playerMovement.isInevitable)
        {
            Debug.Log(
                "Inevitable: passed through enemy."
            );

            return;
        }

        // =====================================================
        // STRIKE
        // =====================================================

        if (playerMovement.isStriking)
        {
            Debug.Log(
                "STRIKE HIT ENEMY!"
            );

            if (
                SFXManager.instance != null &&
                co != null &&
                co.collisionSound != null
            )
            {
                SFXManager.instance.PlaySound(
                    co.collisionSound
                );
            }

            playerMovement
                .MaintainStrikeMomentum();

            if (Analytics.Instance != null)
            {
                Analytics.Instance.ObstacleDestroyed(
                    Analytics.Instance.GetCurrentLevel(),
                    "Enemy"
                );
            }

            Destroy(
                gameObject
            );

            return;
        }

        // =====================================================
        // NORMAL COLLISION
        // =====================================================

        Debug.Log(
            "ENEMY HIT THE PLAYER"
        );

        Debug.Log(
            "GAME OVER"
        );

        if (gm != null)
        {
            gm.EndGame();
        }
    }

    // =========================================================
    // COLLISION CONTROL
    // =========================================================

    public void SetPlayerCollisionIgnored(
        bool ignore
    )
    {
        if (playerMovement == null)
            return;

        if (enemyColliders == null)
        {
            enemyColliders =
                GetComponentsInChildren<Collider>();
        }

        if (playerColliders == null)
        {
            playerColliders =
                playerMovement
                    .GetComponentsInChildren<Collider>();
        }

        foreach (
            Collider enemyCollider
            in enemyColliders
        )
        {
            if (enemyCollider == null)
                continue;

            foreach (
                Collider playerCollider
                in playerColliders
            )
            {
                if (playerCollider == null)
                    continue;

                Physics.IgnoreCollision(
                    enemyCollider,
                    playerCollider,
                    ignore
                );
            }
        }
    }
}