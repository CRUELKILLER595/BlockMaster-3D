using UnityEngine;

public class SCORE : MonoBehaviour
{
    public Transform player;

    public static SCORE instance;

    public int DistanceScore;

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
            return;
        }
    }

    void Update()
    {
        if (player == null)
            return;

        DistanceScore =
            Mathf.FloorToInt(
                player.position.z + 56f
            );
    }
}