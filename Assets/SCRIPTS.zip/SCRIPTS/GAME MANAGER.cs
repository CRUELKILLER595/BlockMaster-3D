using UnityEngine;
using UnityEngine.SceneManagement;

public class GAMEMANAGER : MonoBehaviour
{
    private bool gameHasEnded = false;
    private bool levelCompleted = false;

    public GameObject completeLevelUI;

    // =========================================================
    // AWAKE
    // =========================================================

    void Awake()
    {
        // Every newly loaded level must start unfrozen.
        Time.timeScale = 1f;
    }

    // =========================================================
    // LEVEL COMPLETE
    // =========================================================

    public void OnLevelComplete(int levelIndex)
    {
        if (levelCompleted)
            return;

        levelCompleted = true;

        Debug.Log(
            "LEVEL " +
            levelIndex +
            " COMPLETED"
        );

        // Stop the player.
        PlayerMovement player =
            FindFirstObjectByType<PlayerMovement>();

        if (player != null)
        {
            player.enabled = false;
        }

        // Stop timer.
        TIMER timer =
            FindFirstObjectByType<TIMER>();

        if (timer != null)
        {
            timer.StopTimer();
        }

        // Freeze the completed level.
        Time.timeScale = 0f;

        if (completeLevelUI != null)
        {
            completeLevelUI.SetActive(true);
        }

        LevelManager.UnlockLevel(levelIndex);
    }

    // =========================================================
    // LEVEL FAILURE
    // =========================================================

    public void RecordLevelFailure()
    {
        if (
            gameHasEnded ||
            levelCompleted
        )
        {
            return;
        }

        gameHasEnded = true;

        float distance = 0f;
        int coins = 0;

        if (SCORE.instance != null)
        {
            distance =
                SCORE.instance.DistanceScore;
        }

        if (ScoreManager.instance != null)
        {
            coins =
                ScoreManager.instance.coins;
        }

        if (Analytics.Instance != null)
        {
            Analytics.Instance.LevelFailed(
                Analytics.Instance.GetCurrentLevel(),
                distance,
                coins
            );
        }

        Debug.Log(
            "LEVEL FAILURE RECORDED"
        );
    }

    // =========================================================
    // GAME OVER
    // =========================================================

    public void EndGame()
    {
        if (
            gameHasEnded ||
            levelCompleted
        )
        {
            return;
        }

        Debug.Log(
            "GAME OVER"
        );

        RecordLevelFailure();

        Restart();
    }

    // =========================================================
    // RESTART
    // =========================================================

    public void Restart()
    {
        Time.timeScale = 1f;

        CancelInvoke();

        SceneManager.LoadScene(
            SceneManager.GetActiveScene().buildIndex
        );
    }

    // =========================================================
    // NEXT LEVEL
    // =========================================================

    public void LoadNextLevel()
    {
        // CRITICAL:
        // Completion sets Time.timeScale to 0.
        // Next level must restore it before loading.
        Time.timeScale = 1f;

        CancelInvoke();

        int nextScene =
            SceneManager.GetActiveScene().buildIndex + 1;

        if (
            nextScene >=
            SceneManager.sceneCountInBuildSettings
        )
        {
            Debug.Log(
                "No next level exists."
            );

            return;
        }

        SceneManager.LoadScene(
            nextScene
        );
    }

    // =========================================================
    // LEVEL SELECT
    // =========================================================

    public void LoadMainMenu()
    {
        Time.timeScale = 1f;

        CancelInvoke();

        SceneManager.LoadScene(
            "LEVELS"
        );
    }
}