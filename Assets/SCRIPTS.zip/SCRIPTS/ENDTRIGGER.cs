using UnityEngine;

public class ENDTRIGGER : MonoBehaviour
{
    public GAMEMANAGER gamemanager;

    void Awake()
    {
        if (gamemanager == null)
        {
            gamemanager =
                FindFirstObjectByType<
                    GAMEMANAGER
                >();
        }
    }

    void OnTriggerEnter(
        Collider other
    )
    {
        if (!other.CompareTag("Player"))
            return;

        Debug.Log(
            "PLAYER ENTERED END TRIGGER"
        );

        if (gamemanager != null)
        {
            gamemanager.EndGame();
        }
    }
}