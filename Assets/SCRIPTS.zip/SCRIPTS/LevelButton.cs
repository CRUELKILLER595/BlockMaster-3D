using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class LevelButton : MonoBehaviour
{
    public int levelIndex;

    public TMP_Text highScoreText;

    private Button button;

    void Start()
    {
        button =
            GetComponent<Button>();

        if (button == null)
        {
            Debug.LogError(
                "Button missing on " +
                gameObject.name
            );

            return;
        }

        int unlockedLevel =
            LevelManager.GetUnlockedLevel();

        button.interactable =
            levelIndex <= unlockedLevel;

        int highScore =
            PlayerPrefs.GetInt(
                "HighScore_" +
                levelIndex,
                0
            );

        if (highScoreText != null)
        {
            highScoreText.text =
                highScore.ToString();
        }

        button.onClick.RemoveAllListeners();

        button.onClick.AddListener(
            LoadLevel
        );
    }

    void LoadLevel()
    {
        // IMPORTANT
        Time.timeScale = 1f;

        SceneManager.LoadScene(
            levelIndex + 1
        );
    }
}