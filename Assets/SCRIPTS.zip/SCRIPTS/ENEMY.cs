using UnityEngine;

public class ENEMY : MonoBehaviour
{
    public float SPEED1 = 5F;
    public float SPEED2 = 3F;
    public float SPEED3 = 4F;
    private Vector3 startpos;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        startpos = transform.position;
        
    }

    // Update is called once per frame
    void Update()
    {
        float NEWX=startpos.x + Mathf.PingPong(Time.time * SPEED1, 12);
        transform.position = new Vector3(NEWX, startpos.y, startpos.z);
    }
}
