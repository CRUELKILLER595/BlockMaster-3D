using UnityEngine;

public class JumpPowerUp : MonoBehaviour
{
    public float duration = 10f;

    private bool collected = false;

    void OnTriggerEnter(
        Collider other
    )
    {
        if (collected)
            return;

        if (!other.CompareTag("Player"))
            return;

        PlayerMovement player =
            other.GetComponentInParent<
                PlayerMovement
            >();

        if (player == null)
            return;

        collected = true;

        Debug.Log(
            "JUMP POWER-UP COLLECTED"
        );

        player.ActivateJumpBoost(
            duration
        );

        if (Analytics.Instance != null)
        {
            Analytics.Instance.PowerupCollected(
                Analytics.Instance.GetCurrentLevel(),
                "JumpBoost",
                1
            );
        }

        Destroy(gameObject);
    }
}