using UnityEngine;

public static class LevelManager
{
    private const string KEY = "UnlockedLevel";

    public static int GetUnlockedLevel()
    {
        int level = PlayerPrefs.GetInt(KEY, 1);

        // SAFETY: never allow less than 1
        if (level < 1)
        {
            level = 1;
            PlayerPrefs.SetInt(KEY, 1);
        }

        return level;
    }

  public static void UnlockLevel(int levelIndex)
{
    int unlockedLevel = GetUnlockedLevel();

    if (levelIndex + 1 > unlockedLevel)
    {
        PlayerPrefs.SetInt(KEY, levelIndex + 1);
        PlayerPrefs.Save();

        Debug.Log("Unlocked Level: " + (levelIndex + 1));
    }
}
}
