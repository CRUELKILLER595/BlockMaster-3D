using UnityEngine;

public class FOLLOWUP : MonoBehaviour
{
    public Transform Player;

    public Vector3 offset =
        new Vector3(
            0f,
            8f,
            -10f
        );

    public float smoothSpeed = 10f;

    void Awake()
    {
        FindPlayer();
    }

    void Start()
    {
        FindPlayer();

        if (Player != null)
        {
            transform.position =
                Player.position + offset;
        }
    }

    void LateUpdate()
    {
        if (Player == null)
        {
            FindPlayer();

            if (Player == null)
                return;
        }

        Vector3 target =
            Player.position + offset;

        transform.position =
            Vector3.Lerp(
                transform.position,
                target,
                smoothSpeed *
                Time.deltaTime
            );
    }

    void FindPlayer()
    {
        if (Player != null)
            return;

        PlayerMovement movement =
            FindFirstObjectByType<
                PlayerMovement
            >();

        if (movement != null)
        {
            Player =
                movement.transform;
        }
    }
}